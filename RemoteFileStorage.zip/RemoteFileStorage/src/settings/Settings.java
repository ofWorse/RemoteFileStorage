package settings;

public class Settings {
    public static int SERVER_PORT = 8188;
    public static String SERVER_ADDRESS = "localhost";
    public static String REMOTE_STORAGE_PATH;
    public static String TO_WRITE_PATH;
}
