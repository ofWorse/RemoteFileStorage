package message;

public class FileListRequest extends TokenizedMessage {
    public FileListRequest(String token) {
        super(token);
    }
}
