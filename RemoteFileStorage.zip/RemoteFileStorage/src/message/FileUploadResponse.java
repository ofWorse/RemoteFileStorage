package message;

public class FileUploadResponse extends Message {
}
