package message;

public class FileUploadDone extends Message {
}
