package client.protocol;

import client.transport.Transport;
import exception.AppException;
import message.ErrorMessage;
import message.Message;

public abstract class Handler {
    protected final Transport transport;

    public Handler(Transport transport) {
        this.transport = transport;
    }

    protected <T extends Message> T extractMessageOrFail(Message message, Class<T> expectedType) {
        if (message.getClass() == expectedType) {
            System.out.println("1");
            return expectedType.cast(message);
        } else if (message instanceof ErrorMessage error) {
            System.out.println("2");
            throw new AppException(error.getMessage());
        } else {
            System.out.println("3");
            throw new AppException("unexpected message: " + message);
        }
    }
}
