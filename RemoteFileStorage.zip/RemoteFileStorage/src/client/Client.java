package client;

import client.io.Console;
import client.protocol.FileListHandler;
import client.protocol.FileUploadHandler;
import client.protocol.LoginHandler;
import client.service.FileService;
import client.transport.Transport;
import exception.AppException;
import settings.Settings;

import java.io.File;
import java.nio.file.Path;

public class Client {
    private final Console console = new Console();
    private final FileService fileService = new FileService();
    private String token;

    public static void main(String[] args) {
        new Client().start();
    }

    private void start() {
        String command = null;
        do {
            try {
                console.print(">>> ");
                command = console.read();
                switch (command) {
                    case "login" -> login();
                    case "token" -> token();
                    case "setfldfrom", "setfldto" -> setFolder(command);
                    case "list" -> list();
                    case "upload" -> upload();
                    case "help" -> help();
                    case "exit" -> console.println("bye!");
                    default -> console.println("unrecognized command");
                }
            } catch (AppException e) {
                console.println("error: " + e.getMessage());
            }
        }
        while (!"exit".equals(command));
    }

    private void setFolder(String command) {
        console.print("Введите путь к каталогу: ");
        String path = console.read();
        File dir = new File(path);
        while (!dir.isDirectory()) {
            console.println("Неверно введен путь к каталогу, или каталога не существует.");
            console.print("Попробуйте еще раз: ");
            path = console.read();
            dir = new File(path);
        }
        if ("setfldfrom".equals(command))
            Settings.REMOTE_STORAGE_PATH = dir.toString();
        else Settings.TO_WRITE_PATH = dir.toString();
        System.out.println(Settings.REMOTE_STORAGE_PATH + " -> " + Settings.TO_WRITE_PATH);
    }

    private void login() {
        console.print("login: ");
        var user = console.read();
        console.print("password: ");
        var password = console.read();
        token = Transport.withinConnection(transport ->
                new LoginHandler(transport).login(user, password));
        console.println("login successful");
    }

    private void token() {
        console.println("token = " + token);
    }

    private void list() {
        var files = Transport.withinConnection(transport ->
                new FileListHandler(transport).get(token));
        if (files.isEmpty()) {
            console.println("no files in storage");
        } else {
            console.println("files in storage:");
            files.forEach(console::println);
        }
    }

    private void upload() {
        /*console.print("enter file name (empty for default): ");
        var filepath = console.read();
        while (filepath.isEmpty()) {
            console.println("Doesn't exist or incorrect pathname.");
            console.print("Try again: ");
            filepath = console.read();
        }

        var path = Path.of(filepath);

        if (!fileService.exists(path))
            throw new AppException("no file found.");*/

        var path = Path.of(Settings.REMOTE_STORAGE_PATH);

        fileService.withInputStream(path, input -> {
            var filename = fileService.getFilename(path);
            var filesize = fileService.getFilesize(path);
            Transport.withinConnection(transport ->
                    new FileUploadHandler(transport).upload(token, filename, filesize, input));
        });
    }

    private void help() {
        console.println("СПИСОК КОМАНД, ДОСТУПНЫХ НА ЭТОМ СЕРВЕРЕ:");
        console.println("\n\tlogin - команда для регистрации пользователя. ");
        console.println("\n\ttoken - вывод персонального токена при учете,");
        console.println("\tесли вы были зарегистрированы.");
        console.println("\n\tlist - вывод содержимого из указанного каталога.");
        console.println("\n\tupload - загрузка содержимого из одного каталога в другой.");
        console.println("\n\texit - выйти из сервера.");
    }
}
